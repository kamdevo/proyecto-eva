import VistaServiciosPrincipal from "./components/vista-servicios-principal"

export default function ServiciosApp() {
  return <VistaServiciosPrincipal />
}
