import VistaPropietariosPrincipal from "./components/vista-propietarios-principal"

export default function PropietariosApp() {
  return <VistaPropietariosPrincipal />
}
