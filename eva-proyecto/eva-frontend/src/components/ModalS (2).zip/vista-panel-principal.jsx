import ControlPanel from "./components/vista-panel-control"

export default function Page() {
  return <ControlPanel />
}
